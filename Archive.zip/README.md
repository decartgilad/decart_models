# Decart Models

This project contains models and implementations for the Decart platform.

## Getting Started

More documentation will be added as the project develops.
